function safeExecute(callback) {
    try {
        callback();
    } catch (e) {
        console.error("SidebarWardrobe.Mod.mod - Sydney Panties: Error executing code:", e);
    }
}

function initializeSydneyIntimateVariables() {
    if (typeof State !== 'undefined' && typeof State.variables !== 'undefined') {
        if (typeof State.variables.sydneyPantiesRequest === 'undefined') {
            State.variables.sydneyPantiesRequest = false;
        }
        if (typeof State.variables.sydneyPantiesOn === 'undefined') {
            State.variables.sydneyPantiesOn = true;
        }
        if (typeof State.variables.sydneyBraRequest === 'undefined') {
            State.variables.sydneyBraRequest = false;
        }
        if (typeof State.variables.sydneyBraOn === 'undefined') {
            State.variables.sydneyBraOn = true;
        }
        if (typeof State.variables.sydneyEncouraged === 'undefined') {
            State.variables.sydneyEncouraged = false;
        }
        if (typeof State.variables.sydneyJoin约定 === 'undefined') {
            State.variables.sydneyJoin约定 = false;
        }
        if (typeof State.variables.sydneyJoin时间 === 'undefined') {
            State.variables.sydneyJoin时间 = "";
        }
        if (typeof State.variables.sydneyJoin地点 === 'undefined') {
            State.variables.sydneyJoin地点 = "";
        }
        if (typeof State.variables.sydneyFollowed === 'undefined') {
            State.variables.sydneyFollowed = false;
        }
        if (typeof State.variables.sydneyNightAlleySpotted === 'undefined') {
            State.variables.sydneyNightAlleySpotted = false;
        }
        if (typeof State.variables.sydneyPhotosMild === 'undefined') {
            State.variables.sydneyPhotosMild = 0;
        }
        if (typeof State.variables.sydneyPhotosMedium === 'undefined') {
            State.variables.sydneyPhotosMedium = 0;
        }
        if (typeof State.variables.sydneyPhotosExplicit === 'undefined') {
            State.variables.sydneyPhotosExplicit = 0;
        }
        if (typeof State.variables.sydneyPhotoReward === 'undefined') {
            State.variables.sydneyPhotoReward = 0;
        }
    }
}

function initSydneyIntimateMod() {
    safeExecute(initializeSydneyIntimateVariables);
}

if (typeof $ !== 'undefined' && $.fn && $.fn.on) {
    $(document).on(':passagestart', function() {
        safeExecute(initializeSydneyIntimateVariables);
    });
} else {
    if (typeof document !== 'undefined') {
        document.addEventListener('DOMContentLoaded', function() {
            safeExecute(initSydneyIntimateMod);
        });
    }
}
