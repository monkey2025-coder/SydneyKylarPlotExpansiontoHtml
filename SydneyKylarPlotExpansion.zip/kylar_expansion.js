function safeExecute(callback) {
    try {
        callback();
    } catch (e) {
        console.error("SidebarWardrobe.Mod.mod - Sydney Panties: Error executing code:", e);
    }
}

function initializeSydneyIntimateVariables() {
    if (typeof State !== 'undefined' && typeof State.variables !== 'undefined') {
        if (typeof State.variables.kylar_night_play_suggested === 'undefined') {
            State.variables.kylar_night_play_suggested = false;
        }
        if (typeof State.variables.kylar_night_play_orgasm_count === 'undefined') {
            State.variables.kylar_night_play_orgasm_count = 0;
        }
        if (typeof State.variables.kylar_night_play_count === 'undefined') {
            State.variables.kylar_night_play_count = 0;
        }
    }
}

function initSydneyIntimateMod() {
    safeExecute(initializeSydneyIntimateVariables);
}

if (typeof $ !== 'undefined' && $.fn && $.fn.on) {
    $(document).on(':passagestart', function() {
        safeExecute(initializeSydneyIntimateVariables);
    });
} else {
    if (typeof document !== 'undefined') {
        document.addEventListener('DOMContentLoaded', function() {
            safeExecute(initSydneyIntimateMod);
        });
    }
}
