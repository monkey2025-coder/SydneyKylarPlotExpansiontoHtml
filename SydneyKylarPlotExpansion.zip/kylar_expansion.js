// 安全检查：确保在必要的API可用时才执行代码
function safeExecute(callback) {
    try {
        callback();
    } catch (e) {
        console.error("SidebarWardrobe.Mod.mod - Sydney Panties: Error executing code:", e);
    }
}

function initializeSydneyIntimateVariables() {
    // 在JavaScript中，我们需要使用SugarCube的API来设置变量
    if (typeof State !== 'undefined' && typeof State.variables !== 'undefined') {
        if (typeof State.variables.kylar_night_play_suggested === 'undefined') {
            State.variables.kylar_night_play_suggested = false;
        }
        if (typeof State.variables.kylar_night_play_orgasm_count === 'undefined') {
            State.variables.kylar_night_play_orgasm_count = 0;
        }
        if (typeof State.variables.kylar_night_play_count === 'undefined') {
            State.variables.kylar_night_play_count = 0;
        }
    }
}

// 主初始化函数
function initSydneyIntimateMod() {
    safeExecute(initializeSydneyIntimateVariables);
}

// 检查jQuery是否可用，如果不可用则使用原生事件监听
if (typeof $ !== 'undefined' && $.fn && $.fn.on) {
    // jQuery可用，使用jQuery事件监听
    $(document).on(':passagestart', function() {
        safeExecute(initializeSydneyIntimateVariables);
    });
} else {
    // jQuery不可用，使用原生事件监听
    if (typeof document !== 'undefined') {
        document.addEventListener('DOMContentLoaded', function() {
            safeExecute(initSydneyIntimateMod);
        });
    }
}
