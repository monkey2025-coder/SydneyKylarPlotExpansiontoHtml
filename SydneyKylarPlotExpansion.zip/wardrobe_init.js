function sidebarWardrobeInit() {
    if (!window.V) window.V = {};
    if (!V.wardrobes) V.wardrobes = {
        shopReturn: "wardrobe",
        wardrobe: {
            NOTE: "DO NOT USE THIS OBJECT TO STORE CLOTHES",
            unlocked: true,
            shopSend: true,
            name: "Orphanage",
        }
    };

    const defWardrobe = {
        face: [],
        feet: [],
        hands: [],
        handheld: [],
        head: [],
        legs: [],
        lower: [],
        neck: [],
        over_head: [],
        over_lower: [],
        over_upper: [],
        genitals: [],
        under_lower: [],
        under_upper: [],
        upper: [],
        unlocked: false,
        shopSend: false,
        transfer: true,
        isolated: false,
        locationRequirement: [],
        space: 5,
        name: "",
        shopReturn: ""
    };

    if (!V.wardrobes.customWardrobe) {
        V.wardrobes.customWardrobe = JSON.parse(JSON.stringify(defWardrobe));
    }

    const customW = V.wardrobes.customWardrobe;
    if (customW) {
        customW.name = "Custom Sidebar Wardrobe";
        customW.unlocked = true;
        customW.shopSend = true;
        customW.transfer = true;
        customW.isolated = true;
        customW.space = 20;
        customW.locationRequirement = [];
        customW.shopReturn = "customWardrobe";
    } else {
        console.error("Custom Wardrobe object is undefined!");
    }
}

if (!window.clone) {
    window.clone = function(obj) {
        return JSON.parse(JSON.stringify(obj));
    };
}

$(document).on(':passagerender', function() {
    sidebarWardrobeInit();
});

if (window.wardrobesUpdate) {
    const originalWardrobesUpdate = window.wardrobesUpdate;
    window.wardrobesUpdate = function() {
        originalWardrobesUpdate.apply(this, arguments);
        sidebarWardrobeInit();
    };
} else {
    window.wardrobesUpdate = sidebarWardrobeInit;
}